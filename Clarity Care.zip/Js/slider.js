let currentSlide = 1;
let slideDirection = 1;
let autoSlide;

function showSlides(n) {
  let slides = document.getElementsByClassName('slide');
  let dots = document.getElementsByClassName('dot');

  if (n > slides.length) {
    currentSlide = 1;
    slideDirection = 1;
  }
  if (n < 1) {
    currentSlide = slides.length;
    slideDirection = -1;
  }

  for (let i = 0; i < slides.length; i++) {
    slides[i].style.opacity = 0;
  }

  for (let i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(' active', '');
  }

  slides[currentSlide - 1].style.opacity = 1;
  dots[currentSlide - 1].className += ' active';

  currentSlide = n;
}

autoSlide = setInterval(function () {
  showSlides(currentSlide + slideDirection);
}, 5000);

showSlides(currentSlide);
