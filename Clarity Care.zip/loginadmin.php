<!DOCTYPE html>
<html lang="id">
<head>
    <title>Login - Clarity Care</title>
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div class="logo">
        <img src="CClogo.png" alt="Logo">
    </div>
    <div class="login-container">
        <h2>Login</h2>
        <form id="loginForm" action="login.php" method="POST">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
                <a href="passwordadmin.html" style="color: #000000;"><b>Lupa Password?</b></a>
            </div>
            <div class="form-group">
                <button id="loginButton" type="submit">Masuk</button>
            </div>
            <?php if (isset($error)): ?>
                <p style="color: red;"><?php echo $error; ?></p>
            <?php endif; ?>
        </form>
        <div class="signup">
            <p>Belum punya akun? <a href="registadmin.html" style="color: #0c4446;"><b>Daftar di sini</b></a></p>
        </div>
    </div>
</body>
</html>
